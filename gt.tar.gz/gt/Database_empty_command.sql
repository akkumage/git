<---------Truncate order tables---------------->
SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE `gift_message`;
TRUNCATE TABLE `quote`;
TRUNCATE TABLE `quote_address`;
TRUNCATE TABLE `quote_address_item`;
TRUNCATE TABLE `quote_id_mask`;
TRUNCATE TABLE `quote_item`;
TRUNCATE TABLE `quote_item_option`;
TRUNCATE TABLE `quote_payment`;
TRUNCATE TABLE `quote_shipping_rate`;
TRUNCATE TABLE `reporting_orders`;
TRUNCATE TABLE `sales_bestsellers_aggregated_daily`;
TRUNCATE TABLE `sales_bestsellers_aggregated_monthly`;
TRUNCATE TABLE `sales_bestsellers_aggregated_yearly`;
TRUNCATE TABLE `sales_creditmemo`;
TRUNCATE TABLE `sales_creditmemo_comment`;
TRUNCATE TABLE `sales_creditmemo_grid`;
TRUNCATE TABLE `sales_creditmemo_item`;
TRUNCATE TABLE `sales_invoice`;
TRUNCATE TABLE `sales_invoiced_aggregated`;
TRUNCATE TABLE `sales_invoiced_aggregated_order`;
TRUNCATE TABLE `sales_invoice_comment`;
TRUNCATE TABLE `sales_invoice_grid`;
TRUNCATE TABLE `sales_invoice_item`;
TRUNCATE TABLE `sales_order`;
TRUNCATE TABLE `sales_order_address`;
TRUNCATE TABLE `sales_order_aggregated_created`;
TRUNCATE TABLE `sales_order_aggregated_updated`;
TRUNCATE TABLE `sales_order_grid`;
TRUNCATE TABLE `sales_order_item`;
TRUNCATE TABLE `sales_order_payment`;
TRUNCATE TABLE `sales_order_status_history`;
TRUNCATE TABLE `sales_order_tax`;
TRUNCATE TABLE `sales_order_tax_item`;
TRUNCATE TABLE `sales_payment_transaction`;
TRUNCATE TABLE `sales_refunded_aggregated`;
TRUNCATE TABLE `sales_refunded_aggregated_order`;
TRUNCATE TABLE `sales_shipment`;
TRUNCATE TABLE `sales_shipment_comment`;
TRUNCATE TABLE `sales_shipment_grid`;
TRUNCATE TABLE `sales_shipment_item`;
TRUNCATE TABLE `sales_shipment_track`;
TRUNCATE TABLE `sales_shipping_aggregated`;
TRUNCATE TABLE `sales_shipping_aggregated_order`;
TRUNCATE TABLE `tax_order_aggregated_created`;
TRUNCATE TABLE `tax_order_aggregated_updated`;


ALTER TABLE `gift_message` AUTO_INCREMENT=1; 
ALTER TABLE `quote` AUTO_INCREMENT=1;
ALTER TABLE `quote_address` AUTO_INCREMENT=1;
ALTER TABLE `quote_address_item` AUTO_INCREMENT=1;
ALTER TABLE `quote_id_mask` AUTO_INCREMENT=1;
ALTER TABLE `quote_item` AUTO_INCREMENT=1;
ALTER TABLE `quote_item_option` AUTO_INCREMENT=1;
ALTER TABLE `quote_payment` AUTO_INCREMENT=1;
ALTER TABLE `quote_shipping_rate` AUTO_INCREMENT=1;
ALTER TABLE `reporting_orders` AUTO_INCREMENT=1;
ALTER TABLE `sales_bestsellers_aggregated_daily` AUTO_INCREMENT=1;
ALTER TABLE `sales_bestsellers_aggregated_monthly` AUTO_INCREMENT=1;
ALTER TABLE `sales_bestsellers_aggregated_yearly` AUTO_INCREMENT=1;
ALTER TABLE `sales_creditmemo_comment` AUTO_INCREMENT=1;
ALTER TABLE `sales_creditmemo_grid` AUTO_INCREMENT=1;
ALTER TABLE `sales_creditmemo_item` AUTO_INCREMENT=1;
ALTER TABLE `sales_invoice` AUTO_INCREMENT=1;
ALTER TABLE `sales_invoiced_aggregated` AUTO_INCREMENT=1;
ALTER TABLE `sales_invoiced_aggregated_order` AUTO_INCREMENT=1;
ALTER TABLE `sales_invoice_comment` AUTO_INCREMENT=1;
ALTER TABLE `sales_invoice_grid` AUTO_INCREMENT=1;
ALTER TABLE `sales_invoice_item` AUTO_INCREMENT=1;
ALTER TABLE `sales_order` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_address` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_aggregated_created` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_aggregated_updated` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_grid` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_item` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_payment` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_status_history` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_tax` AUTO_INCREMENT=1;
ALTER TABLE `sales_order_tax_item` AUTO_INCREMENT=1;
ALTER TABLE `sales_payment_transaction` AUTO_INCREMENT=1;
ALTER TABLE `sales_refunded_aggregated` AUTO_INCREMENT=1;
ALTER TABLE `sales_refunded_aggregated_order` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipment` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipment_comment` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipment_grid` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipment_item` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipment_track` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipping_aggregated` AUTO_INCREMENT=1;
ALTER TABLE `sales_shipping_aggregated_order` AUTO_INCREMENT=1;
ALTER TABLE `tax_order_aggregated_created` AUTO_INCREMENT=1;
ALTER TABLE `tax_order_aggregated_updated` AUTO_INCREMENT=1;


<----------Clearing all orders, shipments, transactions etc -------------------->

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `sales_order`;
TRUNCATE `sendfriend_log`;
TRUNCATE `wishlist`;
TRUNCATE `report_event`;

ALTER TABLE `sales_order` AUTO_INCREMENT=1;
ALTER TABLE `sendfriend_log` AUTO_INCREMENT=1;
ALTER TABLE `wishlist` AUTO_INCREMENT=1;
ALTER TABLE `report_event` AUTO_INCREMENT=1;

<-----------------Truncate Customer tables --------------------------------->

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `customer_address_entity`;
TRUNCATE TABLE `customer_address_entity_datetime`;
TRUNCATE TABLE `customer_address_entity_decimal`;
TRUNCATE TABLE `customer_address_entity_int`;
TRUNCATE TABLE `customer_address_entity_text`;
TRUNCATE TABLE `customer_address_entity_varchar`;
TRUNCATE TABLE `customer_entity`;
TRUNCATE TABLE `customer_entity_datetime`;
TRUNCATE TABLE `customer_entity_decimal`;
TRUNCATE TABLE `customer_entity_int`;
TRUNCATE TABLE `customer_entity_text`;
TRUNCATE TABLE `customer_entity_varchar`;
TRUNCATE TABLE `customer_grid_flat`;
TRUNCATE TABLE `customer_log`;
TRUNCATE TABLE `customer_log`;
TRUNCATE TABLE `customer_visitor`;
TRUNCATE TABLE `persistent_session`;
TRUNCATE TABLE `wishlist`;
TRUNCATE TABLE `wishlist_item`;
TRUNCATE TABLE `wishlist_item_option`;


ALTER TABLE `customer_address_entity` AUTO_INCREMENT=1;
ALTER TABLE `customer_address_entity_datetime` AUTO_INCREMENT=1;
ALTER TABLE `customer_address_entity_decimal` AUTO_INCREMENT=1;
ALTER TABLE `customer_address_entity_int` AUTO_INCREMENT=1;
ALTER TABLE `customer_address_entity_text` AUTO_INCREMENT=1;
ALTER TABLE `customer_address_entity_varchar` AUTO_INCREMENT=1;
ALTER TABLE `customer_entity` AUTO_INCREMENT=1;
ALTER TABLE `customer_entity_datetime` AUTO_INCREMENT=1;
ALTER TABLE `customer_entity_decimal` AUTO_INCREMENT=1;
ALTER TABLE `customer_entity_int` AUTO_INCREMENT=1;
ALTER TABLE `customer_entity_text` AUTO_INCREMENT=1;
ALTER TABLE `customer_entity_varchar` AUTO_INCREMENT=1;

<-------------------Truncate Review tables-------------------------------------->

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `review`;
TRUNCATE TABLE `review_detail`;
TRUNCATE TABLE `review_entity_summary`;
TRUNCATE TABLE `review_store`;

<-------------------------Clearing all reviews: -------------------->
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `rating_option_vote`;
TRUNCATE TABLE `rating_option_vote_aggregated`;
TRUNCATE TABLE `review`;
TRUNCATE TABLE `review_detail`;
TRUNCATE TABLE `review_entity_summary`;
TRUNCATE TABLE `review_store`;



<----------------------------TRUNCATE CATEGORIES AND CREATING A ROOT CATEGORY ------------------------------>

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE `catalog_category_entity`; 
TRUNCATE TABLE `catalog_category_entity_datetime`; 
TRUNCATE TABLE `catalog_category_entity_decimal`; 
TRUNCATE TABLE `catalog_category_entity_int`; 
TRUNCATE TABLE `catalog_category_entity_text`; 
TRUNCATE TABLE `catalog_category_entity_varchar`; 
TRUNCATE TABLE `catalog_category_product`; 
TRUNCATE TABLE `catalog_category_product_index`;

INSERT INTO `catalog_category_entity` (`entity_id`, `attribute_set_id`, `parent_id`, `created_at`, `updated_at`, `path`, `position`, `level`, `children_count`) VALUES ('1', '0', '0', '2016-06-23 00:00:00', '2016-06-23 00:00:00', '1', '0', '0', '1'), ('2', '3', '1', '2016-06-23 00:00:00', '2016-06-23 00:00:00', '1/2', '1', '1', '0');
INSERT INTO `catalog_category_entity_datetime` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES ('1', '58', '0', '1', NULL), (2, 58, 0, 2, NULL);
INSERT INTO `catalog_category_entity_decimal` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES
(1, 69, 0, 2, NULL);
INSERT INTO `catalog_category_entity_int` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES ('1', '66', '0', '1', '1'), (2, 43, 0, 2, 1), (3, 50, 0, 2, NULL), (4, 51, 0, 2, 1), (5, 66, 0, 2, 1), (6, 68, 0, 2, 0);
INSERT INTO `catalog_category_entity_text` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES ('1', '64', '0', '1', NULL), (2, 64, 0, 2, NULL), (3, 44, 0, 2, NULL), (4, 47, 0, 2, NULL), (5, 48, 0, 2, NULL), (6, 61, 0, 2, NULL);
INSERT INTO `catalog_category_entity_varchar` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES ('1', '42', '0', '1', 'Root Catalog');
INSERT INTO `catalog_category_entity_varchar` (`value_id`, `attribute_id`, `store_id`, `entity_id`, `value`) VALUES (2, 42, 0, 2, 'Default Category'), (3, 46, 0, 2, NULL), (4, 49, 0, 2, 'PRODUCTS'), (5, 57, 0, 2, NULL), (6, 60, 0, 2, NULL), (7, 65, 0, 2, NULL), (8, 113, 0, 2, 'default-category'), (9, 114, 0, 2, NULL), (10, 143, 0, 2, NULL), (11, 145, 0, 2, NULL), (12, 147, 0, 2, NULL);

SET FOREIGN_KEY_CHECKS = 1;


<----------------------TRUNCATE CATEGORIES--------------------------------------------->
TRUNCATE TABLE `catalog_category_entity`; 
TRUNCATE TABLE `catalog_category_entity_datetime`; 
TRUNCATE TABLE `catalog_category_entity_decimal`; 
TRUNCATE TABLE `catalog_category_entity_int`; 
TRUNCATE TABLE `catalog_category_entity_text`; 
TRUNCATE TABLE `catalog_category_entity_varchar`; 
TRUNCATE TABLE `catalog_category_product`; 
TRUNCATE TABLE `catalog_category_product_index`;


INSERT  INTO `catalog_category_entity`(`entity_id`,`attribute_set_id`,`parent_id`,`created_at`,`updated_at`,`path`,`POSITION`,`level`,`children_count`) VALUES (1,0,0,'2009-02-20 00:25:34','2009-02-20 00:25:34','1',1,0,1),(2,3,0,'2009-02-20 00:25:34','2009-02-20 00:25:34','1/2',1,1,0); 
INSERT  INTO `catalog_category_entity_int`(`value_id`,`attribute_id`,`store_id`,`entity_id`,`value`) VALUES (1,32,0,2,1),(2,32,1,2,1); 
INSERT  INTO `catalog_category_entity_varchar`(`value_id`,`attribute_id`,`store_id`,`entity_id`,`value`) VALUES (1,31,0,1,'Root Catalog'),(2,33,0,1,'root-catalog'),(3,31,0,2,'Default Category'),(4,39,0,2,'PRODUCTS'),(5,33,0,2,'default-category');

<-----------------------------If you already truncated that table, insert records as below:- ---------->

INSERT INTO `catalog_product_link_attribute` VALUES (1,1,'position','int'),(2,4,'position','int'),(3,5,'position','int'),(4,3,'position','int'),(5,3,'qty','decimal');

DELETE FROM catalog_product_entity;

<---After truncating the category tables you might get duplicate entry errors for URL keys so you need to clear category URL keys from url_rewrite table.--->
DELETE FROM `url_rewrite` WHERE `entity_type` = 'category'


<<<<<<<<<<<<<<<<<<<<---------Clearing all products-------------------------->>>>>>>>>>>>>>>>>>>>>>>


SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `catalog_product_bundle_option`;
TRUNCATE TABLE `catalog_product_bundle_option_value`;
TRUNCATE TABLE `catalog_product_bundle_selection`;
TRUNCATE TABLE `catalog_product_entity_datetime`;
TRUNCATE TABLE `catalog_product_entity_decimal`;
TRUNCATE TABLE `catalog_product_entity_gallery`;
TRUNCATE TABLE `catalog_product_entity_int`;
TRUNCATE TABLE `catalog_product_entity_media_gallery`;
TRUNCATE TABLE `catalog_product_entity_media_gallery_value`;
TRUNCATE TABLE `catalog_product_entity_text`;
TRUNCATE TABLE `catalog_product_entity_tier_price`;
TRUNCATE TABLE `catalog_product_entity_varchar`;
TRUNCATE TABLE `catalog_product_link`;
TRUNCATE TABLE `catalog_product_link_attribute`;
TRUNCATE TABLE `catalog_product_link_attribute_decimal`;
TRUNCATE TABLE `catalog_product_link_attribute_int`;
TRUNCATE TABLE `catalog_product_link_attribute_varchar`;
TRUNCATE TABLE `catalog_product_link_type`;
TRUNCATE TABLE `catalog_product_option`;
TRUNCATE TABLE `catalog_product_option_price`;
TRUNCATE TABLE `catalog_product_option_title`;
TRUNCATE TABLE `catalog_product_option_type_price`;
TRUNCATE TABLE `catalog_product_option_type_title`;
TRUNCATE TABLE `catalog_product_option_type_value`;
TRUNCATE TABLE `catalog_product_super_attribute_label`;
TRUNCATE TABLE `catalog_product_super_attribute`;
TRUNCATE TABLE `catalog_product_super_link`;
TRUNCATE TABLE `catalog_product_website`;
TRUNCATE TABLE `catalog_category_product_index`;
TRUNCATE TABLE `catalog_category_product`;
TRUNCATE TABLE `cataloginventory_stock_item`;
TRUNCATE TABLE `cataloginventory_stock_status`;
TRUNCATE TABLE `cataloginventory_stock`;
TRUNCATE TABLE `catalog_product_entity`;
INSERT  INTO `catalog_product_link_type`(`link_type_id`,`code`) VALUES (1,'relation'),(2,'bundle'),(3,'super'),(4,'up_sell'),(5,'cross_sell');
INSERT  INTO `catalog_product_link_attribute`(`product_link_attribute_id`,`link_type_id`,`product_link_attribute_code`,`data_type`) VALUES (1,2,'qty','decimal'),(2,1,'position','int'),(3,4,'position','int'),(4,5,'position','int'),(6,1,'qty','decimal'),(7,3,'position','int'),(8,3,'qty','decimal');
INSERT  INTO `cataloginventory_stock`(`stock_id`,`website_id`,`stock_name`) VALUES (1,0,'Default');
